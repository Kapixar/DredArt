# DredArt - your paiting comrade
Chrome and Firefox extension for Dredark/Drednot/DSA
Consists of 2 parts: Render and Creator

  
Created from the idea of **MOSAIC** project

## Download from Chrome Web Store
https://chrome.google.com/webstore/detail/ocgomfneelmigjgpgnapekmedbmimamm

## Instalation as local file
1. Click Code button
2. Download ZIP
3. Extract zip
4. Head to chrome://extensions/
5. Enable Developer Mode
6. Click Load unpacked button
7. Select and upload the extracted folder
8. Disable Developer Mode

## Usage
In top bar (where socials are) there should be yellow pallete you can click.


### DredArt | Render
Part of the tool is available on this website: http://dredart.myartsonline.com
Render generates pixel arts from images.

### Discord server with more details
https://discord.gg/uNgD6vv67c